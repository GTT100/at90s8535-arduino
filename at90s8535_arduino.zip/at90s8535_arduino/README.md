# Arduino Board Definition for AT90S8535

AT90S8535（Classic AVR / avr3アーキテクチャ）用のArduino IDEボード定義です。

---

## スペック

| 項目 | 値 |
|------|-----|
| アーキテクチャ | Classic AVR (avr3) |
| Flash | 8KB |
| SRAM | 512B |
| EEPROM | 512B |
| GPIO | 32ピン (PA/PB/PC/PD 各8ビット) |
| ADC | 10bit × 8ch (PA0-PA7) |
| タイマー | Timer0(8bit), Timer1(16bit), Timer2(8bit async) |
| UART | ×1 (PD0=RXD, PD1=TXD) |
| SPI | ×1 (PB4=SS, PB5=MOSI, PB6=MISO, PB7=SCK) |
| TWI | なし |
| 外部割り込み | INT0(PD2), INT1(PD3) |

---

## インストール方法

1. Arduino IDEの設定フォルダを開く
   - Windows: `%APPDATA%\Arduino15\packages\` または `Documents\Arduino\hardware\`
   - macOS: `~/Library/Arduino15/` または `~/Documents/Arduino/hardware/`
   - Linux: `~/.arduino15/` または `~/Arduino/hardware/`

2. `hardware/` フォルダに `at90s8535/` ディレクトリごとコピーする：
   ```
   Arduino/
   └── hardware/
       └── at90s8535/
           ├── boards.txt
           ├── platform.txt
           └── variants/
               └── at90s8535/
                   └── pins_arduino.h
   ```

3. Arduino IDEを再起動する

4. **ツール → ボード** に `AT90S8535 (8MHz External)` が表示される

---

## ピンマッピング

```
Arduino Pin  Port Pin  機能
-----------  --------  -------------------------
0 - 7        PA0-PA7   デジタル / アナログ入力 A0-A7
8 - 15       PB0-PB7   デジタル / SPI(12=SS,13=MOSI,14=MISO,15=SCK)
16 - 23      PC0-PC7   デジタル
24 - 31      PD0-PD7   デジタル / UART(24=RX,25=TX)
                        INT0=26(PD2), INT1=27(PD3)
                        PWM: 28(OC1B), 29(OC1A), 31(OC2)
```

---

## 書き込み方法

AT90S8535はブートローダー非対応のため、**ISPライター必須**です。

### avrdude コマンド例（USBtinyISP使用）

```bash
avrdude -p at90s8535 -c usbtiny -U flash:w:sketch.hex:i
```

### フューズビット（8MHz外部クリスタル）

| フューズ | 値 |
|---------|-----|
| LOW  | 0xE1 |
| HIGH | 0xD9 |

> ⚠️ AT90S8535のフューズはATmegaと異なります。書き込み前に必ずデータシートを確認してください。

---

## 注意事項

- **AT90S8535はClassic AVR**（avr3）のため、新しいAVRの機能（TWI/I2C等）は使えません。
- Arduino標準ライブラリの一部はATmega向けに最適化されており、動作しない場合があります。
- `Wire.h`（I2C）は使用不可です。
- `avr-gcc`のバージョンによっては`at90s8535`ターゲットがサポートされていない場合があります。`avr-gcc -mmcu=at90s8535`で確認してください。

---

## avr-gcc サポート確認

```bash
avr-gcc -mmcu=at90s8535 -print-file-name=libgcc.a
# パスが返れば対応している
```
